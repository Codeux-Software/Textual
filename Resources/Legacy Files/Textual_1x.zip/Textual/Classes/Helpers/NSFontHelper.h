@interface NSFont (NSFontHelper)

- (NSFont*)convertToItalics;

@end