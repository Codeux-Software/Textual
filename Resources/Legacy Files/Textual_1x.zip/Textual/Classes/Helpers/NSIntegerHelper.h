//
//  NSIntegerHelper.h
//  Textual
//
//  Created by Michael Morris on 9/3/10.
//  Copyright 2010 Codeux Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface NSIntegerHelper : NSObject {

}

@end
