#import <Cocoa/Cocoa.h>

#include "IRCClient.h"
#include "NSObject+DDExtensions.h"

@interface TPIUserJoinValidation : NSObject 

- (void)messageReceivedByServer:(IRCClient*)client 
						 sender:(NSDictionary*)senderDict 
						message:(NSDictionary*)message;
	
- (NSArray*)pluginSupportsServerInputCommands;

@end