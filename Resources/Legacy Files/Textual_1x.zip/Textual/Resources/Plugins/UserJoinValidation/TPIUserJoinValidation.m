#import "TPIUserJoinValidation.h"
#include <RegexKit/RegexKit.h>

@implementation TPIUserJoinValidation

- (NSArray*)pluginSupportsServerInputCommands
{
	return [NSArray arrayWithObjects:@"join", nil];
}

- (void)messageReceivedByServer:(IRCClient*)client 
						 sender:(NSDictionary*)senderDict 
						message:(NSDictionary*)messageDict
{
	NSString *command = [[messageDict objectForKey:@"messageCommand"] lowercaseString];
	NSString *server = [[messageDict objectForKey:@"messageServer"] lowercaseString];
	
	if ([server hasSuffix:@"wyldryde.org"]) {
		if ([command isEqualToString:@"JOIN"]) {	
			NSString *nickname = [[senderDict objectForKey:@"senderNickname"] lowercaseString];
			NSString *channel = [[[messageDict objectForKey:@"messageParamaters"] objectAtIndex:0] lowercaseString];
			
			if ([nickname isEqualToString:@"hamburger"] && [channel isEqualToString:@"#gamerx287"]) {
				[[client invokeOnMainThread] sendLine:[NSString stringWithFormat:@"GZLINE %@ 35d Your behavior is not conducive to the desired environment. If you feel this ban is in error you may appeal it at: http://www.wyldryde.org/bans/", nickname]];
			} else if ([nickname isEqualToString:@"hotgirl"] && [[senderDict objectForKey:@"senderUsername"] isEqualToString:@"girl"]) {
				[[client invokeOnMainThread] sendLine:[NSString stringWithFormat:@"GZLINE %@ 35d Your behavior is not conducive to the desired environment. If you feel this ban is in error you may appeal it at: http://www.wyldryde.org/bans/", nickname]];
			} 
		}
	}
}

@end