#import <Cocoa/Cocoa.h>

#include "IRCClient.h"
#include "NSObject+DDExtensions.h"
#include "NSStringHelper.h"

@interface BotnetValidation : NSObject

- (void)messageReceivedByServer:(IRCClient*)client 
						 sender:(NSDictionary*)senderDict 
						message:(NSDictionary*)message;

- (NSArray*)pluginSupportsServerInputCommands;

@end