#import "BotnetValidation.h"
#include <RegexKit/RegexKit.h>

#define PRIVATE_KEY @"18313f29226617a12d608cf892ce12e2774bd7fe11bb8cfb2afa6bf0c528762c65db69e0d182b9857e22acbf2cff743f7e1f8b94f55261cc28b9f0673ef1e91624735dc131862f8687d4cc24e25cec26275afaa69298150a2244a67d75fa92fb895e6939"
#define PUBLIC_KEY @"c0d4a21de75a9f36e7a3a2a7d4bb7a353f481957e0c5865e469849e9ca9b765d375f1a6c44cf67ce7f5c1552b5a13ebf33f07f1b7d87bfdc845c6156cbfc8732299ccffb11028e1d0499acb29c1e878248f473e2c2c3599758ac27bb2e9dc4481ec6751c"

@implementation BotnetValidation

- (void)checkInternetBlacklist:(IRCClient*)c withHostname:(NSString*)hostname
{
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	
	NSURL *address = [NSURL URLWithString:[NSString stringWithFormat:@"http://discovery.wyldryde.org/dnsbl.php?ip=%@&k=%@", hostname, PRIVATE_KEY]];
	
	NSURLRequest *chRequest = [NSURLRequest requestWithURL:address
											   cachePolicy:NSURLRequestUseProtocolCachePolicy
										   timeoutInterval:10];
	
	NSData *response = [NSURLConnection sendSynchronousRequest:chRequest returningResponse:nil error:NULL]; 
	
	if (response) {
		NSString *key = [[[NSString alloc] initWithData:response encoding:NSASCIIStringEncoding] trim];
		
		if ([key isEqualToString:PUBLIC_KEY]) {
			[[c invokeOnMainThread] sendLine:[NSString stringWithFormat:@"GLINE *@%@ 35d Clones, trojan bots, spam bots, xdcc/fserves/leech bots, zombies, and drones are prohibited. If you feel this ban is in error you may appeal it at: http://www.wyldryde.org/bans/", hostname]];
		} 
	}
	
	[pool release];
}

- (NSArray*)pluginSupportsServerInputCommands
{
	return [NSArray arrayWithObjects:@"notice", nil];
}

- (void)messageReceivedByServer:(IRCClient*)client 
						 sender:(NSDictionary*)senderDict 
						message:(NSDictionary*)messageDict
{
	NSString *server = [[messageDict objectForKey:@"messageServer"] lowercaseString];
	
	if ([server hasSuffix:@"wyldryde.org"]) {
		
		NSString *text = [messageDict objectForKey:@"messageSequence"];
		
		// Possible connect types
		//[06/12/2010 -:- 07:45:03 AM] *** Notice -- Client connecting on port 6667: SL0RD (sidney@blk-222-69-46.eastlink.ca) [clients]
		//[06/12/2010 -:- 07:46:08 AM] *** Notice -- Client connecting at Nikon.WyldRyde.org: claude (Mibbit@ip72-218-78-142.hr.hr.cox.net)
		
		NSString *nickname = nil;
		NSString *hostname = nil;
		
		if ([text hasPrefix:@"*** Notice -- Client connecting at"]) {
			NSArray *chunks = [text componentsSeparatedByString:@" "];
			
			nickname = [[chunks objectAtIndex:7] lowercaseString];
			hostname = [[chunks objectAtIndex:8] lowercaseString];
		} else if ([text hasPrefix:@"*** Notice -- Client connecting on port"]) {
			NSArray *chunks = [text componentsSeparatedByString:@" "];
			
			nickname = [[chunks objectAtIndex:8] lowercaseString];
			hostname = [[chunks objectAtIndex:9] lowercaseString];
		}
		
		if (nickname && hostname) {
			hostname = [hostname substringWithRange:NSMakeRange(1, ([hostname length] - 2))];
			
			if ([nickname isMatchedByRegex:@"^\\[(([a-zA-Z0-9]+)\\|([a-zA-Z0-9]+)\\|([a-zA-Z0-9]+))\\]$"] ||
				[nickname isMatchedByRegex:@"^\\{(([a-zA-Z0-9]+)\\\\([a-zA-Z0-9]+)\\\\([a-zA-Z0-9]+))\\}$"] || 
			    [nickname isMatchedByRegex:@"^([a-zA-Z0-9]+)\\|([a-zA-Z0-9]+)\\|([a-zA-Z0-9]+)\\|([a-zA-Z0-9]+)\\|([a-zA-Z0-9]+)$"] ||
				[hostname hasPrefix:@"flooder@"] || [nickname isEqualToString:@"cool_man"] ||
				([nickname isMatchedByRegex:@"^(([a-z]{1})([0-9]{1,5}))$"] && [hostname isMatchedByRegex:@"^(([a-z]{1})([0-9]{1,5}))\\@"])) {
				
				if ([[NSArray arrayWithObjects:@"B00", nil] containsObject:nickname]) return;
				
				[[client invokeOnMainThread] sendLine:[NSString stringWithFormat:@"GZLINE %@ 35d Clones, trojan bots, spam bots, xdcc/fserves/leech bots, zombies, and drones are prohibited. If you feel this ban is in error you may appeal it at: http://www.wyldryde.org/bans/", nickname]];
			}
			
			[self checkInternetBlacklist:client withHostname:hostname];
		}
	}
}

@end