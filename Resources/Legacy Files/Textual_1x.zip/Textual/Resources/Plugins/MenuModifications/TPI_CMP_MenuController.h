#import <Cocoa/Cocoa.h>

#include "TPI_CustomMenus.h"
#include "MenuController.h"

@interface MenuController (TPI_CMP_MenuController)
- (void)postLinkToTextualHomepage:(id)sender;
@end