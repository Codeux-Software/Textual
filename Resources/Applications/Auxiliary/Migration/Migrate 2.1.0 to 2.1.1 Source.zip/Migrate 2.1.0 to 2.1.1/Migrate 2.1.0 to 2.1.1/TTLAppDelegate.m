//
//  TTLAppDelegate.m
//  Migrate 2.1.0 to 2.1.1
//
//  Created by Michael Morris on 8/13/12.
//  Copyright (c) 2012 Codeux Software. All rights reserved.
//

#import "TTLAppDelegate.h"

@implementation TTLAppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
	NSFileManager *fileManager = [NSFileManager defaultManager];

	if (fileManager) {
		NSString *oldPath = [@"~/Library/Containers/com.codeux.irc.textual/"	stringByExpandingTildeInPath];
		NSString *newPath = [@"~/Library/Containers/com.codeux.textual/"		stringByExpandingTildeInPath];

		NSString *oldPathBackup = [@"~/Library/Containers/com.codeux.irc.textual.backup/"	stringByExpandingTildeInPath];

		BOOL isDirectory = NO;

		if ([fileManager fileExistsAtPath:oldPath isDirectory:&isDirectory]) {
			if (isDirectory) {
				NSError *operationError;

				[fileManager copyItemAtPath:oldPath
									 toPath:oldPathBackup
									  error:&operationError];

				if (operationError) {
					return;
				}

				[fileManager removeItemAtPath:oldPath
										error:&operationError];

				if (operationError) {
					return;
				}

				[fileManager copyItemAtPath:oldPathBackup
									 toPath:newPath
									  error:&operationError];

				if (operationError) {
					return;
				}
			}
		}
	}
}
	
@end
