//
//  TTLAppDelegate.h
//  Migrate 2.1.0 to 2.1.1
//
//  Created by Michael Morris on 8/13/12.
//  Copyright (c) 2012 Codeux Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface TTLAppDelegate : NSObject <NSApplicationDelegate>
@property (assign) IBOutlet NSWindow *window;
@property (strong) IBOutlet NSTextField *label;
@end
